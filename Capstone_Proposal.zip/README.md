# MLND_Capstone
Udacity's MLND Capstone project
Capstone Topic - Plant Seedling Classification

Downlaoad the data set from the following location:-
https://www.kaggle.com/c/plant-seedlings-classification/data
